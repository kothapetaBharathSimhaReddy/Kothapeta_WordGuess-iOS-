//
//  Kothapeta_WordGuessTests.swift
//  Kothapeta_WordGuessTests
//
//  Created by Bharath Simha Reddy Kothapeta on 10/20/24.
//

import Testing
@testable import Kothapeta_WordGuess

struct Kothapeta_WordGuessTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
