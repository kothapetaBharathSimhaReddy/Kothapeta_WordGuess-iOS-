//
//  ViewController.swift
//  Kothapeta_WordGuess
//
//  Created by Bharath Simha Reddy Kothapeta on 10/20/24.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var wordsGuessedLabel: UILabel!
    
    @IBOutlet weak var wordsRemainingLabel: UILabel!
    
    @IBOutlet weak var totalWordsLabel: UILabel!
    
    @IBOutlet weak var userGuessLabel: UILabel!
    
    @IBOutlet weak var guessLetterField: UITextField!
    
    @IBOutlet weak var guessLetterButtonPressed: UIButton!
    
    @IBOutlet weak var hintLabel: UILabel!
    
    @IBOutlet weak var guessCountLabel: UILabel!
    
    @IBOutlet weak var statusLabel: UILabel!
    
    @IBOutlet weak var playAgainButtonPressed: UIButton!
    
    @IBOutlet weak var displayImage: UIImageView!
    
    
    // Array of words, hints, and images
    let wordsArray = [
        ("Kothapeta", "Bharath", "Bharath"),
        ("Apple", "Fruit", "Apple"),
        ("BMW", "Vehicle", "BMW"),
        ("Lion", "Animal", "Lion"),
        ("iPhone", "Mobile", "Iphone")
    ]
    
    // Game Variables
    var currentWord: String = ""
    var currentHint: String = ""
    var currentImage: String = ""
    var maxNumOfWrongGuesses = 10
    var wrongGuesses = 0
    var guessCount = 0
    var wordsGuessed = 0
    var currentWordIndex = 0
    var guessedLetters: Set<Character> = []
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Setup initial game state
        playAgainButtonPressed.isHidden = true
        newGame()
    }
    
    
    // Start a new game
    func newGame() {
        currentWordIndex = 0
        wordsGuessed = 0
        wrongGuesses = 0
        guessCount = 0
        guessedLetters.removeAll()
        loadNewWord()
        updateLabels()
        statusLabel.text = ""
        playAgainButtonPressed.isHidden = false
    }
    
    
    // Load the current word, hint, and image
    func loadNewWord() {
        let currentItem = wordsArray[currentWordIndex]
        currentWord = currentItem.0.uppercased()
        currentHint = currentItem.1
        currentImage = currentItem.2
        
        hintLabel.text = "Hint: \(currentHint)"
        userGuessLabel.text = String(repeating: "_ ", count: currentWord.count)
        guessCountLabel.text = "You have made \(wrongGuesses) guesses."
        displayImage.image = nil
    }
    
    func updateLabels() {
        wordsGuessedLabel.text = "Words Guessed Successfully: \(wordsGuessed)"
        wordsRemainingLabel.text = "Words Remaining: \(wordsArray.count - wordsGuessed)"
        totalWordsLabel.text = "Total Words in Game: \(wordsArray.count)"
    }
    
    
    @IBAction func guessLetterButtonPressed(_ sender: UIButton) {
        guard let letter = guessLetterField.text?.uppercased().last else { return }
        
        // Clear the text field after a guess
        guessLetterField.text = ""
        incrementGuessCount()

        // Only process the guess if the letter hasn't been guessed before
        if !guessedLetters.contains(letter) {
            guessedLetters.insert(letter)
            processGuess(letter: letter)
        }
    }

    // Increment guess count and update the UI
    func incrementGuessCount() {
        guessCount += 1
        guessCountLabel.text = "You have made \(guessCount) guesses."
    }

    // Handle the logic for processing the guessed letter
    func processGuess(letter: Character) {
        if currentWord.contains(letter) {
            updateGuessedWord(for: letter)
            verifyWinCondition()
        } else {
            handleWrongGuess()
        }
    }

    // Handle the wrong guess logic
    func handleWrongGuess() {
        wrongGuesses += 1
        guessCountLabel.text = "You have made \(wrongGuesses) wrong guesses."
        
        if wrongGuesses >= maxNumOfWrongGuesses {
            statusLabel.text = "You have used all available guesses. Please play again."
            playAgainButtonPressed.isHidden = false
        }
    }

    // Update the displayed word based on guessed letters
    func updateGuessedWord(for letter: Character) {
        userGuessLabel.text = currentWord.map { guessedLetters.contains($0) ? "\($0) " : "_ " }.joined()
    }

    // Check if the user has guessed the word correctly
    func verifyWinCondition() {
        if !(userGuessLabel.text?.contains("_") ?? true) {
            wordsGuessed += 1
            displayImage.image = UIImage(named: currentImage)
            statusLabel.text = "You guessed the word!"
            playAgainButtonPressed.isHidden = false
        }
    }
    
    @IBAction func playAgainButtonPressed(_ sender: UIButton) {
        if wordsGuessed < wordsArray.count {
            moveToNextWord()
        } else {
            showEndGameState()
        }
        updateLabels()
    }
    
    // Move to the next word by resetting variables and loading new word
    func moveToNextWord() {
        currentWordIndex += 1
        resetWordState()
        playAgainButtonPressed.isHidden = true
        loadNewWord()
    }
    
    // Reset variables related to the current word
    func resetWordState() {
        wrongGuesses = 0
        guessCount = 0
        guessedLetters.removeAll()
    }
    
    // Show end game status
    func showEndGameState() {
        statusLabel.text = "Congratulations! You have guessed all words correctly!"
        wordsGuessedLabel.text = "Words Guessed Successfully: \(wordsGuessed)"
        wordsRemainingLabel.text = "Words Remaining: 0"
        totalWordsLabel.text = "Total words in game: \(wordsArray.count)"
        guessLetterButtonPressed.isHidden = true
        playAgainButtonPressed.isHidden = false
    }
}
